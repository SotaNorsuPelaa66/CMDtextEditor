import time
import typer
import datetime

app = typer.Typer()

@app.command()
def run(file: str):
    status = True
    lineCheck = 1
    f = open(file, "r")


    code = []

    while status:
        var = f.readline()
        if var == "":
            status = False
        code.append(var)
        lineCheck = lineCheck + 1

    code1 = list(map(lambda x:x.strip(),code))






    line = 1
    for i in code1:
        if i == "echo":
            var2 = code1[line]
            print(var2)
        if i == "sleep":
            time.sleep(2.6)

        line = line + 1

@app.command()
def help():
    print("This is pyBasic demo compiler/runner")
    print(datetime.datetime.now())


if __name__ == "__main__":
    app()

