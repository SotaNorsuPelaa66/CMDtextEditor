import time

code = []

def compile():
    for c in range(20):
        print("")
    line = 0
    for i in code:
        line = line + 1
        if i == "sleep1":
            time.sleep(1)
        elif i == "sleep2":
            time.sleep(2)
        elif i == "sleep3":
            time.sleep(3)
        elif i == "echo":
            var = code[line]
            print(var)
        exit()

print("Type ;123 to end session and write results")

while True:
    cp = input(">> ")
    if cp == ";123":
        compile()
    code.append(cp)